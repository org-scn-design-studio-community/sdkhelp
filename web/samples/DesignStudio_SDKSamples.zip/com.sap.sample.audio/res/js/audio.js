sap.designstudio.sdk.Component.subclass("com.sap.sample.audio.Audio", function() {

	this.tagAudio = null;

	this.init = function() {
		this.tagAudio = $("<audio/>");
		this.$().append(this.tagAudio);
	};

	this.src = function(audioUrl) {
		if (audioUrl !== undefined) {
			this.tagAudio.attr("src",  audioUrl);
			this.tagAudio[0].play();
			return this;
		} else {
			return this.tagAudio.src;
		}
	};
});
