sap.designstudio.sdk.Component.subclass("com.sap.sample.jsongrabber.JsonGrabber", function() {

	var STYLE_DIV = "style=\"background-color:white;\"";
	var STYLE_DIV1 = "style=\"margin-bottom:5px;\"";
	var STYLE_DIV2 = "style=\"margin-bottom:5px;margin-top:10px;\"";
	var STYLE_TITLE = "style=\"font-size:x-large;line-height:100%;white-space:nowrap;\"";
	var STYLE_SUBTITLE = "style=\"font-size:small;line-height:100%;white-space:nowrap;\"";
	var STYLE_TEXTAREA = "style=\"box-sizing:border-box; font-family:Consolas;width:100%;height:100px;border:1;\"";
	var ATTR_TEXTAREA = "cols=\"35\" rows=\"10\"";

	var saveDataResultCell = null;
	var saveDataResultCellList = null;
	var saveDataResultCellSet = null;
	var saveDataResultSet = null;
	var saveMetadata = null;
	var saveShowPropertyType = null;
	var saveIsPrettyPrint = null;

	var jqTextareaMetadata = null;
	var jqTextareaData = null;

	this.init = function() {
		this.$().addClass(STYLE_DIV);
	}

	this.afterUpdate = function() {
		this.$().empty();

		var data = null;
		if (saveShowPropertyType === "ResultCell") {
			data = saveDataResultCell;
		} else if (saveShowPropertyType === "ResultCellList") {
			data = saveDataResultCellList;
		} else if (saveShowPropertyType === "ResultCellSet") {
			data = saveDataResultCellSet;
		} else if (saveShowPropertyType === "ResultSet") {
			data = saveDataResultSet;
		}
		var strPropertyType = saveShowPropertyType;

		var jqDiv1 = $("<div " + STYLE_DIV1 + ">");
		this.$().append(jqDiv1);

		jqDiv1.append($("<b><span " + STYLE_TITLE + ">JSON Grabber</style></b>"));
		jqDiv1.append($("<p/>"));

		var metadataTitle = "Meta-Data Run-Time JSON" + ((strPropertyType != "") ? " for property type <b>" + strPropertyType + "</b>": "");
		jqDiv1.append($("<span " + STYLE_SUBTITLE + ">" +  metadataTitle + "</style>"));
		jqDiv1.append($("<br/>"));

		this.jqTextareaMetadata = $("<textarea " + STYLE_TEXTAREA + " " + ATTR_TEXTAREA + " name=\"jsongrabber1\"></textarea>");
		this.$().append(this.jqTextareaMetadata);

		var jqDiv2 = $("<div " + STYLE_DIV2 + ">");
		this.$().append(jqDiv2);

		var dataTitle = "Data Run-Time JSON" + ((strPropertyType != "") ? " for property type <b>" + strPropertyType + "</b>" : "");
		jqDiv2.append($("<span " + STYLE_SUBTITLE + ">" + dataTitle + "</style>"));
		jqDiv2.append($("<br/>"));

		this.jqTextareaData = $("<textarea " + STYLE_TEXTAREA + " " + ATTR_TEXTAREA + " name=\"jsongrabber2\"></textarea>");
		this.$().append(this.jqTextareaData);

		this.jqTextareaMetadata.val(saveMetadata ? prettyPrint(saveMetadata) : "No Meta-data Run-time JSON.");
		this.jqTextareaData.val(data ? prettyPrint(data) : "No Data Run-time JSON.");

		var heightTextarea = (this.$().height() - jqDiv1.outerHeight(true) - jqDiv2.outerHeight(true)) / 2;
		this.jqTextareaMetadata.height(heightTextarea);
		this.jqTextareaData.height(heightTextarea);
	};

	var prettyPrint = function(string) {
		var indent = saveIsPrettyPrint ? 2 : 0;
		return JSON.stringify(string, null, indent);
	};

	// property setter/getter functions

	this.dataResultCell = function(value) {
		if (value === undefined) {
			return saveDataResultCell;
		} else {
			saveDataResultCell = value;
			return this;
		}
	};

	this.dataResultCellList = function(value) {
		if (value === undefined) {
			return saveDataResultCellList;
		} else {
			saveDataResultCellList = value;
			return this;
		}
	};

	this.dataResultCellSet = function(value) {
		if (value === undefined) {
			return saveDataResultCellSet;
		} else {
			saveDataResultCellSet = value;
			return this;
		}
	};

	this.dataResultSet = function(value) {
		if (value === undefined) {
			return saveDataResultSet;
		} else {
			saveDataResultSet = value;
			return this;
		}
	};

	this.metadata = function(value) {
		if (value === undefined) {
			return saveMetadata;
		} else {
			saveMetadata = value;
			return this;
		}
	};

	this.showPropertyType = function(value) {
		if (value === undefined) {
			return saveShowPropertyType;
		} else {
			saveShowPropertyType = value;
			return this;
		}
	};
	
	this.isPrettyPrint = function(value) {
		if (value === undefined) {
			return saveIsPrettyPrint;
		} else {
			saveIsPrettyPrint = value;
			return this;
		}
	};
});
