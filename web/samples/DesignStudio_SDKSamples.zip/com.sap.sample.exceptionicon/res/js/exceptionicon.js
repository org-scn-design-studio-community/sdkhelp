sap.designstudio.sdk.Component.subclass("com.sap.sample.exceptionicon.ExceptionIcon", function() {

	var that = this;

	var cell_data = null;
	var iconred_val = "";
	var iconyellow_val = "";
	var icongreen_val = "";
	var valueiconred_val = 0.0;
	var valueicongreen_val = 0.0;
	var valueiconyellow_val = 0.0;
	var exactmatch_val = false;
	var onclick_val = undefined;

	this.init = function() {
		this.img = $('<img width=16px height=16px/>');
		this.$().append(this.img);
		this.img.click(function() {
			that.fireEvent("onclick");
		});
	};

	this.afterUpdate = function() {
		if (cell_data) {
			var number = cell_data.data[0];
			if (exactmatch_val) {
				if (Math.round(number) == this.valueicongreen()) {
					showShape(icongreen_val, "green");
				} else if (Math.round(number) == this.valueiconyellow()) {
					showShape(iconyellow_val, "yellow");
				} else if (Math.round(number) == this.valueiconred()) {
					showShape(iconred_val, "red");
				} else {
					showShape(null, null);
				}
			} else {
				if (number > this.valueicongreen()) {
					showShape(icongreen_val, "green");
				} else if (number > this.valueiconyellow()) {
					showShape(iconyellow_val, "yellow");
				} else if (number > this.valueiconred()) {
					showShape(iconred_val, "red");
				} else {
					showShape(null, null);
				}
			}
		}

		if (onclick_val) {
			this.$().css("cursor", "pointer");
		} else {
			this.$().css("cursor", "");
		}
	};

	function showShape(icon, sColor) {
		if (icon) {
			that.$().css("visibility", "");
			that.img.attr("src", icon);
			that.img.css("display", "");
		} else if (sColor) {
			that.$().css("background-color", sColor);
			that.$().css("display", "");
			that.img.css("display", "none");
		} else {
			that.$().css("visibility", "hidden");
			that.img.css("display", "none");
		}
	} 

	this.cell = function(value) {
		if (value === undefined) {
			return cell_data;
		} else {
			cell_data = value;
			return this;
		}
	};

	this.iconred = function(value) {
		if (value === undefined) {
			return iconred_val;
		} else {
			iconred_val = value;
			return this;
		}
	};

	this.iconyellow = function(value) {
		if (value === undefined) {
			return iconyellow_val;
		} else {
			iconyellow_val = value;
			return this;
		}
	};
	
	this.icongreen = function(value) {
		if (value === undefined) {
			return icongreen_val;
		} else {
			icongreen_val = value;
			return this;
		}
	};

	this.valueiconred = function(value) {
		if (value === undefined) {
			return valueiconred_val;
		} else {
			valueiconred_val = value;
			return this;
		}
	};

	this.valueicongreen = function(value) {
		if (value === undefined) {
			return valueicongreen_val;
		} else {
			valueicongreen_val = value;
			return this;
		}
	};

	this.valueiconyellow = function(value) {
		if (value === undefined) {
			return valueiconyellow_val;
		} else {
			valueiconyellow_val = value;
			return this;
		}
	};

	this.exactmatch = function(value) {
		if (value === undefined) {
			return exactmatch_val;
		} else {
			exactmatch_val = value;
			return this;
		}
	};

	this.onclick = function(value) {
		if (arguments.length == 0) {
			return onclick_val;
		} else {
			onclick_val = value;
			return this;
		}
	};
});