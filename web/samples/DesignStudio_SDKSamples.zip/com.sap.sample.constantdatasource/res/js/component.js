sap.designstudio.sdk.DataSource.subclass("com.sap.sample.constantdatasource.ConstantDataSource", function() {

	var oMetadataRuntimeJson = 
	{
		"dimensions": [
			{
				"key": "cols",
				"text": "Columns",
				"axis": "COLUMNS",
				"axis_index": 0,
				"members": [
					{
						"key": "A",
						"text": "A"
					},
					{
						"key": "B",
						"text": "B"
					},
					{
						"key": "C",
						"text": "C"
					}
				]
			},
			{
				"key": "rows",
				"text": "Rows",
				"axis": "ROWS",
				"axis_index": 0,
				"members": [
					{
						"key": "1",
						"text": "1"
					},
					{
						"key": "2",
						"text": "2"
					}
				]
			}
		],
		"externalDimensions": [
			{
				"key": "measures",
				"text": "Measures",
				"containsMeasures": true,
				"members": [
					{
						"key": "measure",
						"text": "Measure",
					}
				]
			}
		],
		"locale": "en",
	};

	var oDataRuntimeJson =
	{
		"selection": [
			-1,
			-1
		],
		"data": [
			11,
			21,
			31,
			12,
			22,
			33
		],
		"formattedData": [
			"11",
			"21",
			"31",
			"12",
			"22",
			"33"
		],
		"tuples": [
			[0, 0],
			[1, 0],
			[2, 0],
			[0, 1],
			[1, 1],
			[2, 1]
		],
		"axis_columns": [
			[0, -1],
			[1, -1],
			[2, -1]
		],
		"axis_rows": [
			[-1, 0],
			[-1, 1]
		],
		"columnCount": 3,
		"rowCount": 2,
		"locale": "en"
	};

	function merge(oToMerge1, oToMerge2) {
		var oTarget = {};
		jQuery.extend(oTarget, oToMerge1, oToMerge2);
		return oTarget;
	}

	var oFullDataRuntimeJson = merge(oDataRuntimeJson, oMetadataRuntimeJson);

	this.fetchData = function(oSelection, oOptions) {
		return oFullDataRuntimeJson;
	};

	this.metadata = function(value) {
		if (value === undefined) {
			return JSON.stringify(oMetadataRuntimeJson);
		} else {
			return this;
		}
	}
});
