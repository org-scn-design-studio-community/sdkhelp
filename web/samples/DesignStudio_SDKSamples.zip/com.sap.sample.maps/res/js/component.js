sap.designstudio.sdk.Component.subclass("com.sap.sample.maps.GoogleMaps", function() {

	var DEFAULT_LATITUDE = 49.290818;
	var DEFAULT_LONGITUDE = 8.643104;

	var that = this;

	this.init = function() {
		var mapOptions = {
			center: new google.maps.LatLng(DEFAULT_LATITUDE, DEFAULT_LONGITUDE),
			zoom: 14,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		this.map = new google.maps.Map(this.$()[0], mapOptions);
		google.maps.event.addListener(this.map, 'zoom_changed', function() {
			that.firePropertiesChangedAndEvent(["zoom"], "onZoom");
		});
	};

	// property setter/getter functions

	this.maptype = function(value) {
		if (value === undefined) {
			return this.map.getMapTypeId();
		} else {
			this.map.setMapTypeId(value);
			return this;
		}
	};

	this.zoom = function(value) {
		if (value === undefined) {
			return this.map.getZoom();
		} else {
			this.map.setZoom(value);
			return this;
		}
	};
});

sap.designstudio.sdk.Component.subclass("com.sap.sample.maps.DataMap", function() {
	var DEFAULT_LATITUDE = 49.290818;
	var DEFAULT_LONGITUDE = 8.643104;

	var meta_data = null;
	var saveAddressDimension = null;
	var saveRedMarker = null;
	var saveBlueMarker = null;
	var saveRedScalingFactor = 20000;
	var saveBlueScalingFactor = 20000;

	var that = this;

	this.init = function() {
		var mapOptions = {
			center: new google.maps.LatLng(DEFAULT_LATITUDE, DEFAULT_LONGITUDE),
			zoom: 2,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		this.map = new google.maps.Map(this.$()[0], mapOptions);
		this.geocoder = new google.maps.Geocoder();
	};

	this.afterUpdate = function() {
		if (meta_data) {
			var relevant_dim = null;
			for (var i = 0; i < meta_data.dimensions.length; i++) {
				var dim = meta_data.dimensions[i];
				if (dim.key === saveAddressDimension) {
					relevant_dim = dim;
					break;
				}
			}
			if (relevant_dim) {
				drawSeries(saveRedMarker, saveBlueMarker, relevant_dim.members);
			}
		}
	};

	function drawSeries(aSeries1, aSeries2, aMembers) {
		var iNumbersOfMarkers = Math.min(100, aMembers.length); // Limit needed as Google Geocoder has a load limit

		for (var i = 0; i < iNumbersOfMarkers; i++) {
			var nPixels1 = 0;
			var nPixels2 = 0;
			var sMember = aMembers[i].text;
			if (aSeries1) {
				var nValue1 = aSeries1.data[i];
				nPixels1 = nValue1 / saveRedScalingFactor;
			}
			if (aSeries2) {
				var nValue2 = aSeries2.data[i];
				nPixels2 = nValue2 / saveBlueScalingFactor;
			}
			drawMarker(sMember, nPixels1, nPixels2, i);
		}
	}

	function drawMarker(city, nPixels1, nPixels2, i) {
		setTimeout(function() { // Slowing down usage of Google Geocoder allows more markers to be shown
			that.geocoder.geocode({
				'address': city
			}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					if (nPixels1) {
						var sPath1 = 'm 0,0 l0,' + (-nPixels1) + 'l5,0, l0,' + nPixels1 + '  z';
						var marker1 = new google.maps.Marker({
							map: that.map,
							position: results[0].geometry.location,
							icon: {
								path: sPath1,
								scale: 1,
								strokeColor: 'red',
								fillColor: 'red',
								fillOpacity: 0.5
							}
						});
					}
					if (nPixels2) {
						var sPath2 = 'm 0,0 l0,' + (-nPixels2) + 'l5,0, l0,' + nPixels2 + '  z';
						var marker2 = new google.maps.Marker({
							map: that.map,
							position: results[0].geometry.location,
							icon: {
								anchor: new google.maps.Point(2, -2),
								path: sPath2,
								scale: 1,
								strokeColor: 'blue',
								fillColor: 'blue',
								fillOpacity: 0.5
							}
						});
					}
				} else {
					// alert("Geocode failed for the following reason: " + status);
				}
			});
		}, i * 500);
	}

	// property setter/getter functions	

	this.metadata = function(value) {
		if (value === undefined) {
			return meta_data;
		} else {
			meta_data = value;
			return this;
		}
	};

	this.addressdimension = function(value) {
		if (value === undefined) {
			return saveAddressDimension;
		} else {
			saveAddressDimension = value;
			return this;
		}
	};

	this.redmarker = function(value) {
		if (value === undefined) {
			return saveRedMarker;
		} else {
			saveRedMarker = value;
			return this;
		}
	};

	this.bluemarker = function(value) {
		if (value === undefined) {
			return saveBlueMarker;
		} else {
			saveBlueMarker = value;
			return this;
		}
	};

	this.redscalingfactor = function(value) {
		if (value === undefined) {
			return saveRedScalingFactor;
		} else {
			saveRedScalingFactor = value;
			return this;
		}
	};

	this.bluescalingfactor = function(value) {
		if (value === undefined) {
			return saveBlueScalingFactor;
		} else {
			saveBlueScalingFactor = value;
			return this;
		}
	};
});