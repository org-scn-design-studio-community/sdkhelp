sap.designstudio.sdk.Component.subclass("com.sap.sample.timer.Timer", function() {

	var that = this;

	this.afterUpdate = function() {
		if (saveIsShowIconInApplication) {
			this.$().addClass("timer");
		} else {
			this.$().removeClass("timer");
		}		
	};
	
	var runner = null;

	this.isRunning = function(value) {
		if (value === undefined) {
			return (runner != null);
		} else {
			if (value == "START") {
				if (runner != null) {
					window.clearInterval(runner);
					runner = null;
				};
				runner = window.setInterval(function() { that.fireEvent(["onTimer"]); }, this.millis());
			} else if (value == "STOP") {
				if (runner != null) {
					window.clearInterval(runner);
					runner = null;
				};
			}
			return this;
		};
	};

	// property setter/getter functions
	
	var saveMillis = 1000;

	this.millis = function(value) {
		if (value === undefined) {
			return saveMillis;
		} else {
			if (value >= 0) {
				saveMillis = value;
			}
			return this;
		}
	};
	
	var saveIsShowIconInApplication = true;

	this.isShowIconInApplication = function(value) {
		if (value === undefined) {
			return saveIsShowIconInApplication;
		} else {
			saveIsShowIconInApplication = value;
			return this;
		}
	};
});
