sap.designstudio.sdk.Component.subclass("com.sap.sample.sparkline.Sparkline", function() {

	var that = this;

	var sparkline_data = undefined;
	var cssstyle = undefined;
	var path = undefined;

	this.init = function() {
		var container = this.$()[0];
		var graph = d3.select(container).append("svg:svg").attr("width", "100%").attr("height", "100%");
		//appending an svg:path element
		path = graph.append("svg:path");
	};

	this.afterUpdate = function() {
		drawSparkline();
	};

	function drawSparkline(){
		if(sparkline_data && sparkline_data.data) {
			var width = that.$().outerWidth(true);
			var height = that.$().outerHeight(true);
			 // create a simple data array that we'll plot with a line (this array represents only the Y values, X will just be the index location)

			var data = sparkline_data.data;

			var lengthData = data.length;
			var maxY = d3.max(data);
			var minY = d3.min(data);
			// X scale will fit values from 0-10 within pixels 0-100
			var x = d3.scale.linear().domain([0, lengthData-1]).range([0, width]);
			// Y scale will fit values from 0-10 within pixels 0-100
			var y = d3.scale.linear().domain([maxY, minY]).range([0, height]);

			// create a line object that represents the SVN line we're creating
			var line = d3.svg.line()
				// assign the X function to plot our line as we wish
				.x(function(d,i) { 
					// verbose logging to show what's actually being done
					// console.log('Plotting X value for data point: ' + d + ' using index: ' + i + ' to be at: ' + x(i) + ' using our xScale.');
					// return the X coordinate where we want to plot this datapoint
					return x(i);
				})
				.y(function(d) { 
					// verbose logging to show what's actually being done
					// console.log('Plotting Y value for data point: ' + d + ' to be at: ' + y(d) + " using our yScale.");
					// return the Y coordinate where we want to plot this datapoint
					return y(d); 
				});

				// display the line by setting the path with the data line we created above
				var svgline = path.attr("d", line(data));
				svgline.classed("sapSparkline", true);
				if (cssstyle != undefined) {
					svgline.attr("style", cssstyle);
				}
		}
	}

	this.data = function(value) {
		if (value === undefined) {
			return sparkline_data;
		} else {
			sparkline_data = value;
			return this;
		}
	};

	this.css = function(value) {
		if(value === undefined) {
			return cssstyle;
		} else {
			cssstyle = value;
			return this;
		}
	};
});